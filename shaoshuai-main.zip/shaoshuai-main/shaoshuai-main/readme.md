# 声明

本项目仅用于学习交流。使用本项目所产生的任何后果由使用者自行承担。在使用本项目之前，请确保您已充分了解相关法律法规，并确保您的行为符合所在国家或地区的法律要求。未经授权的情况下，请勿将本项目用于商业用途或其他非法用途。

# 参考与相关链接

https://zhuanlan.zhihu.com/p/62703610
https://cloud.tencent.com/developer/article/1630099
https://www.douyin.com/root/search/%E5%B0%91%E5%B8%85%E4%B8%8B%E9%A3%9E%E6%9C%BA?aid=954607ed-bdb0-4ad6-8c3e-8175278358bd&modal_id=7378168942000442633&type=general