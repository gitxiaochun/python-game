import sys
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


class VideoProcessor:
    def __init__(self, font_path="simhei.ttf"):
        self.font_path = font_path

    # 在图像上添加文字的函数
    def cv2ImgAddText(self, img, text, left, top, textColor=(0, 255, 0), textSize=20):
        if isinstance(img, np.ndarray):
            img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(img)
            fontText = ImageFont.truetype(self.font_path, textSize, encoding="utf-8")
            draw.text((left, top), text, textColor, font=fontText)
            return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)

    # 用于处理单帧的函数，接受自定义文字参数
    def process_frame(self, frame, custom_text, text_position=(50, 15), text_color=(0, 0, 0),
                      text_size=50):
        if frame is None:
            sys.exit(1)

        image_gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        image_blurred = cv2.GaussianBlur(image_gray, (7, 7), 0)
        image_threshold1 = cv2.adaptiveThreshold(image_blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,
                                                 5, 2)
        img_threshold1_blurred = cv2.GaussianBlur(image_threshold1, (5, 5), 0)
        _, img_threshold2 = cv2.threshold(img_threshold1_blurred, 200, 255, cv2.THRESH_BINARY)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        img_opening = cv2.bitwise_not(cv2.morphologyEx(cv2.bitwise_not(img_threshold2), cv2.MORPH_OPEN, kernel))

        # 调用 cv2ImgAddText，在图像上添加自定义文字
        img_word = self.cv2ImgAddText(img_opening, custom_text, text_position[0], text_position[1], text_color,
                                      text_size)

        img_final = cv2.GaussianBlur(img_word, (3, 3), 0)
        return img_final


# 主入口，当直接运行此脚本时使用
if __name__ == '__main__':
    cap = cv2.VideoCapture('D:\project\shaoshuai-main\shaoshuai-main\少帅下飞机.mp4')
    processor = VideoProcessor()

    while True:
        _, frame = cap.read()

        # 可以自由修改传递给 process_frame 的自定义文字
        img_final = processor.process_frame(frame, custom_text="少帅")

        cv2.imshow("Processed Video", img_final)
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
